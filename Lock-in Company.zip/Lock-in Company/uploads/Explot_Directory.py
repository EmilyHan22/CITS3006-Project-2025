import os

# Get the parent directory (Lock-in Company folder)
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)

print(f"Looking at: {parent_dir}\n")

# Get all items in the parent directory
items = os.listdir(parent_dir)

# Separate files and directories
files = []
directories = []

for item in items:
    item_path = os.path.join(parent_dir, item)
    if os.path.isfile(item_path):
        files.append(item)
    elif os.path.isdir(item_path):
        directories.append(item)

# Display directories
print("Directories:")
for directory in sorted(directories):
    print(directory)

# Display files
print("\nFiles:")
for file in sorted(files):
    print(file)

# Read and display app.py
app_py_path = os.path.join(parent_dir, "app.py")
if os.path.exists(app_py_path):
    print("\n" + "="*60)
    print("CONTENTS OF app.py")
    print("="*60 + "\n")
    
    with open(app_py_path, "r", encoding="utf-8") as f:
        content = f.read()
        print(content)
else:
    print("\napp.py not found in parent directory.")

