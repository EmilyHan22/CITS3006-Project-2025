import os
import zipfile
import time

# Get the current user's desktop
desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

# Name of the zip file
zip_filename = os.path.join(desktop_path, "uploads_files.zip")

# Path to the uploads folder
uploads_dir = os.path.join(os.getcwd(), "uploads")  # Adjust if your uploads folder is elsewhere

# Create the zip file
with zipfile.ZipFile(zip_filename, 'w') as zipf:
    for file in os.listdir(uploads_dir):
        file_path = os.path.join(uploads_dir, file)
        if os.path.isfile(file_path):
            zipf.write(file_path, arcname=file)
            print(file)  # Print each file added

print(f"All files in {uploads_dir} have been zipped into {zip_filename}")

# Keep the CMD window open for 10 seconds to see output
time.sleep(10)
